export interface User {
  _id: string;
  id: string;
  name: string;
  email: string;
  points: number;
  rank: number;
  streak: number;
  badges: string[];
  completedSurveys?: CompletedSurvey[];
  role: 'user' | 'admin';
  createdAt?: string;
}

export interface CompletedSurvey {
  survey: string;
  completedAt: string;
}

export interface Question {
  _id?: string;
  questionText: string;
  questionType: 'single_choice' | 'multiple_choice' | 'text' | 'rating' | 'yes_no';
  options?: string[];
  required?: boolean;
}

export interface Survey {
  _id: string;
  title: string;
  description?: string;
  type: 'short' | 'long';
  questions: Question[];
  points: number;
  status: 'active' | 'inactive' | 'draft';
  completions?: number;
  createdBy?: string;
  isCompleted?: boolean;
  createdAt?: string;
  endDate?: string;
}

export interface ActivityLog {
  _id: string;
  user: string | User;
  activityType: 'survey_completion' | 'daily_login' | 'streak_bonus' | 'reward_claimed' | 'admin_adjustment';
  survey?: string | Survey;
  pointsEarned: number;
  description?: string;
  metadata?: Record<string, any>;
  createdAt: string;
}

export interface Reward {
  _id: string;
  user: string | User;
  amount: number;
  status: 'pending' | 'processing' | 'paid' | 'cancelled';
  period: 'weekly' | 'monthly';
  periodStart: string;
  periodEnd: string;
  rank: number;
  paymentMethod?: string;
  paymentDetails?: Record<string, any>;
  paidAt?: string;
  paidBy?: string;
  notes?: string;
  createdAt: string;
}

export interface LeaderboardEntry {
  rank: number;
  user: {
    id: string;
    name: string;
    badges: string[];
  };
  points: number;
}

export interface DashboardData {
  user: {
    id: string;
    name: string;
    email: string;
    points: number;
    rank: number;
    streak: number;
    badges: string[];
    completedSurveysCount: number;
  };
  recentActivity: ActivityLog[];
  activitySummary: ActivitySummary[];
  rewards: Reward[];
  nextBadge: {
    name: string;
    threshold: number;
  } | null;
  progressToNext: number;
}

export interface ActivitySummary {
  _id: string;
  totalPoints: number;
  count: number;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  name: string;
  email: string;
  password: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data?: T;
  errors?: any[];
}

export interface AdminDashboardStats {
  users: {
    total: number;
    newToday: number;
    activeToday: number;
  };
  surveys: {
    total: number;
    active: number;
    totalCompletions: number;
  };
  points: {
    totalDistributed: number;
    today: number;
  };
  rewards: {
    total: number;
    pending: number;
    totalPaid: number;
  };
  recentActivity: ActivityLog[];
  topUsers: User[];
}
