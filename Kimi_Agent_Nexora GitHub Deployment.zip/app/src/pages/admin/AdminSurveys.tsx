import { useEffect, useState } from 'react';
import { surveyAPI } from '../../services/api';
import type { Survey, Question } from '../../types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ClipboardList, 
  Plus,
  Edit2,
  Trash2,
  Loader2,
  ArrowLeft,
  CheckCircle,
  Coins
} from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

export default function AdminSurveys() {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingSurvey, setEditingSurvey] = useState<Survey | null>(null);
  const [selectedSurvey, setSelectedSurvey] = useState<Survey | null>(null);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'short' | 'long'>('short');
  const [points, setPoints] = useState(50);
  const [status, setStatus] = useState<'active' | 'inactive' | 'draft'>('active');
  const [questions, setQuestions] = useState<Question[]>([]);

  useEffect(() => {
    fetchSurveys();
  }, []);

  const fetchSurveys = async () => {
    try {
      setIsLoading(true);
      const response = await surveyAPI.getSurveys({});
      if (response.data.success) {
        setSurveys(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching surveys:', error);
      toast.error('Failed to load surveys');
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setType('short');
    setPoints(50);
    setStatus('active');
    setQuestions([]);
    setEditingSurvey(null);
  };

  const handleOpenDialog = (survey?: Survey) => {
    if (survey) {
      setEditingSurvey(survey);
      setTitle(survey.title);
      setDescription(survey.description || '');
      setType(survey.type);
      setPoints(survey.points);
      setStatus(survey.status);
      setQuestions(survey.questions);
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    try {
      const surveyData = {
        title,
        description,
        type,
        points,
        status,
        questions: questions.length > 0 ? questions : [
          {
            questionText: 'How satisfied are you with our service?',
            questionType: 'rating',
            required: true
          },
          {
            questionText: 'Would you recommend us to others?',
            questionType: 'yes_no',
            required: true
          },
          {
            questionText: 'Any additional feedback?',
            questionType: 'text',
            required: false
          }
        ]
      };

      if (editingSurvey) {
        await surveyAPI.updateSurvey(editingSurvey._id, surveyData);
        toast.success('Survey updated successfully');
      } else {
        await surveyAPI.createSurvey(surveyData);
        toast.success('Survey created successfully');
      }

      setIsDialogOpen(false);
      resetForm();
      fetchSurveys();
    } catch (error) {
      toast.error('Failed to save survey');
    }
  };

  const handleDelete = async () => {
    if (!selectedSurvey) return;

    try {
      await surveyAPI.deleteSurvey(selectedSurvey._id);
      toast.success('Survey deleted successfully');
      setIsDeleteDialogOpen(false);
      fetchSurveys();
    } catch (error) {
      toast.error('Failed to delete survey');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'inactive':
        return 'bg-red-100 text-red-700';
      case 'draft':
        return 'bg-gray-100 text-gray-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <ClipboardList className="w-8 h-8 mr-3 text-[#007BFF]" />
              Manage Surveys
            </h1>
            <p className="text-gray-600 mt-1">
              Create and manage surveys for users
            </p>
          </div>
          <div className="flex space-x-3 mt-4 md:mt-0">
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Create Survey
            </Button>
            <Link to="/admin">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-gray-900">
                {surveys.filter(s => s.status === 'active').length}
              </p>
              <p className="text-sm text-gray-500">Active</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-gray-900">
                {surveys.filter(s => s.status === 'draft').length}
              </p>
              <p className="text-sm text-gray-500">Drafts</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold text-gray-900">
                {surveys.reduce((acc, s) => acc + (s.completions || 0), 0)}
              </p>
              <p className="text-sm text-gray-500">Total Completions</p>
            </CardContent>
          </Card>
        </div>

        {/* Surveys List */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-12 text-center">
                <Loader2 className="w-8 h-8 animate-spin text-[#007BFF] mx-auto" />
              </div>
            ) : surveys.length > 0 ? (
              <div className="divide-y">
                {surveys.map((survey) => (
                  <div key={survey._id} className="p-6 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{survey.title}</h3>
                          <Badge className={getStatusColor(survey.status)}>
                            {survey.status}
                          </Badge>
                          <Badge className={survey.type === 'short' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}>
                            {survey.type}
                          </Badge>
                        </div>
                        <p className="text-gray-600 mb-3">{survey.description}</p>
                        <div className="flex items-center space-x-6 text-sm text-gray-500">
                          <span className="flex items-center">
                            <ClipboardList className="w-4 h-4 mr-1" />
                            {survey.questions.length} questions
                          </span>
                          <span className="flex items-center">
                            <Coins className="w-4 h-4 mr-1 text-[#FFD700]" />
                            {survey.points} points
                          </span>
                          <span className="flex items-center">
                            <CheckCircle className="w-4 h-4 mr-1 text-green-500" />
                            {survey.completions || 0} completions
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenDialog(survey)}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedSurvey(survey);
                            setIsDeleteDialogOpen(true);
                          }}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center">
                <ClipboardList className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No surveys yet</h3>
                <p className="text-gray-500 mb-4">Create your first survey to get started</p>
                <Button onClick={() => handleOpenDialog()}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Survey
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Create/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingSurvey ? 'Edit Survey' : 'Create Survey'}</DialogTitle>
              <DialogDescription>
                {editingSurvey ? 'Update survey details' : 'Create a new survey for users'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Survey title"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Survey description"
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select value={type} onValueChange={(v: 'short' | 'long') => setType(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="short">Short (50 pts)</SelectItem>
                      <SelectItem value="long">Long (150 pts)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="points">Points</Label>
                  <Input
                    id="points"
                    type="number"
                    value={points}
                    onChange={(e) => setPoints(parseInt(e.target.value))}
                  />
                </div>
                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={status} onValueChange={(v: 'active' | 'inactive' | 'draft') => setStatus(v)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={!title}>
                {editingSurvey ? 'Update' : 'Create'} Survey
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Survey</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete "{selectedSurvey?.title}"? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
