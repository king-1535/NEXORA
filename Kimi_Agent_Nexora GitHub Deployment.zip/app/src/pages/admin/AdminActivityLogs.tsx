import { useEffect, useState } from 'react';
import { adminAPI } from '../../services/api';
import type { ActivityLog } from '../../types';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, 
  ClipboardList, 
  CheckCircle,
  Flame,
  Gift,
  Star,
  Loader2,
  ArrowLeft,
  ArrowRight,
  TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

export default function AdminActivityLogs() {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchLogs();
  }, [page, filter]);

  const fetchLogs = async () => {
    try {
      setIsLoading(true);
      const params: any = { page, limit: 50 };
      if (filter !== 'all') {
        params.activityType = filter;
      }
      const response = await adminAPI.getActivityLogs(params);
      if (response.data.success) {
        setLogs(response.data.data);
        setTotalPages(response.data.totalPages);
      }
    } catch (error) {
      console.error('Error fetching activity logs:', error);
      toast.error('Failed to load activity logs');
    } finally {
      setIsLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'survey_completion':
        return <ClipboardList className="w-5 h-5 text-blue-500" />;
      case 'daily_login':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'streak_bonus':
        return <Flame className="w-5 h-5 text-orange-500" />;
      case 'reward_claimed':
        return <Gift className="w-5 h-5 text-purple-500" />;
      case 'admin_adjustment':
        return <Star className="w-5 h-5 text-red-500" />;
      default:
        return <Activity className="w-5 h-5 text-gray-500" />;
    }
  };

  const getActivityLabel = (type: string) => {
    const labels: Record<string, string> = {
      survey_completion: 'Survey Completed',
      daily_login: 'Daily Login',
      streak_bonus: 'Streak Bonus',
      reward_claimed: 'Reward Claimed',
      admin_adjustment: 'Admin Adjustment'
    };
    return labels[type] || type;
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'survey_completion':
        return 'bg-blue-100 text-blue-700';
      case 'daily_login':
        return 'bg-green-100 text-green-700';
      case 'streak_bonus':
        return 'bg-orange-100 text-orange-700';
      case 'reward_claimed':
        return 'bg-purple-100 text-purple-700';
      case 'admin_adjustment':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const activityTypes = [
    { value: 'all', label: 'All Activities' },
    { value: 'survey_completion', label: 'Survey Completions' },
    { value: 'daily_login', label: 'Daily Logins' },
    { value: 'streak_bonus', label: 'Streak Bonuses' },
    { value: 'reward_claimed', label: 'Reward Claims' },
    { value: 'admin_adjustment', label: 'Admin Adjustments' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center">
              <Activity className="w-8 h-8 mr-3 text-[#007BFF]" />
              Activity Logs
            </h1>
            <p className="text-gray-600 mt-1">
              Track all user activities on the platform
            </p>
          </div>
          <div className="flex space-x-3 mt-4 md:mt-0">
            <Link to="/admin">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>

        {/* Filter */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-2">
              {activityTypes.map((type) => (
                <Button
                  key={type.value}
                  variant={filter === type.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => {
                    setFilter(type.value);
                    setPage(1);
                  }}
                >
                  {type.label}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Activity List */}
        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-12 text-center">
                <Loader2 className="w-8 h-8 animate-spin text-[#007BFF] mx-auto" />
              </div>
            ) : logs.length > 0 ? (
              <div className="divide-y">
                {logs.map((log) => (
                  <div key={log._id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-start space-x-4">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        {getActivityIcon(log.activityType)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <p className="font-medium text-gray-900">
                              {typeof log.user === 'object' ? log.user.name : 'Unknown User'}
                            </p>
                            <Badge className={getActivityColor(log.activityType)}>
                              {getActivityLabel(log.activityType)}
                            </Badge>
                          </div>
                          <span className="text-sm text-gray-500">
                            {new Date(log.createdAt).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-gray-600 mt-1">{log.description}</p>
                        <div className="flex items-center mt-2 space-x-4">
                          <span className="flex items-center text-green-600 font-semibold">
                            <TrendingUp className="w-4 h-4 mr-1" />
                            +{log.pointsEarned} points
                          </span>
                          {log.survey && typeof log.survey === 'object' && (
                            <span className="text-sm text-gray-500">
                              Survey: {log.survey.title}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center">
                <Activity className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No activity found</h3>
                <p className="text-gray-500">Activity logs will appear here</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-6">
            <Button
              variant="outline"
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>
            <span className="text-gray-600">
              Page {page} of {totalPages}
            </span>
            <Button
              variant="outline"
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
