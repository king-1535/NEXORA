import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { adminAPI } from '../../services/api';
import type { AdminDashboardStats, ActivityLog, User } from '../../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Users, 
  ClipboardList, 
  Coins, 
  Gift,
  TrendingUp,
  ArrowRight,
  Loader2,
  Activity,
  DollarSign,
  UserPlus,
  CheckCircle
} from 'lucide-react';
import { toast } from 'sonner';

export default function AdminDashboard() {
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      const response = await adminAPI.getDashboardStats();
      if (response.data.success) {
        setStats(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching admin dashboard:', error);
      toast.error('Failed to load dashboard stats');
    } finally {
      setIsLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'survey_completion':
        return <ClipboardList className="w-4 h-4 text-blue-500" />;
      case 'daily_login':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'streak_bonus':
        return <TrendingUp className="w-4 h-4 text-orange-500" />;
      case 'reward_claimed':
        return <Gift className="w-4 h-4 text-purple-500" />;
      default:
        return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const getActivityLabel = (type: string) => {
    const labels: Record<string, string> = {
      survey_completion: 'Survey Completed',
      daily_login: 'Daily Login',
      streak_bonus: 'Streak Bonus',
      reward_claimed: 'Reward Claimed',
      admin_adjustment: 'Admin Adjustment'
    };
    return labels[type] || type;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Overview of platform performance and user activity
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Link to="/admin/users">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center">
              <Users className="w-6 h-6 mb-2" />
              <span className="text-sm">Manage Users</span>
            </Button>
          </Link>
          <Link to="/admin/surveys">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center">
              <ClipboardList className="w-6 h-6 mb-2" />
              <span className="text-sm">Manage Surveys</span>
            </Button>
          </Link>
          <Link to="/admin/rewards">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center">
              <Gift className="w-6 h-6 mb-2" />
              <span className="text-sm">Rewards</span>
            </Button>
          </Link>
          <Link to="/admin/activity-logs">
            <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center">
              <Activity className="w-6 h-6 mb-2" />
              <span className="text-sm">Activity Logs</span>
            </Button>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100">Total Users</p>
                  <p className="text-3xl font-bold">{stats?.users.total.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-blue-100">
                <UserPlus className="w-4 h-4 mr-1" />
                +{stats?.users.newToday} today
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Active Surveys</p>
                  <p className="text-3xl font-bold">{stats?.surveys.active}</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <ClipboardList className="w-6 h-6" />
                </div>
              </div>
              <div className="mt-4 text-sm text-purple-100">
                {stats?.surveys.totalCompletions.toLocaleString()} completions
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100">Points Today</p>
                  <p className="text-3xl font-bold">{stats?.points.today.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Coins className="w-6 h-6" />
                </div>
              </div>
              <div className="mt-4 text-sm text-green-100">
                {stats?.points.totalDistributed.toLocaleString()} total
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100">Pending Rewards</p>
                  <p className="text-3xl font-bold">{stats?.rewards.pending}</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Gift className="w-6 h-6" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-orange-100">
                <DollarSign className="w-4 h-4 mr-1" />
                ${stats?.rewards.totalPaid.toLocaleString()} paid
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Activity */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2 text-[#007BFF]" />
                  Recent Activity
                </CardTitle>
                <CardDescription>Latest platform activity</CardDescription>
              </div>
              <Link to="/admin/activity-logs">
                <Button variant="ghost" size="sm">
                  View All
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {stats?.recentActivity && stats.recentActivity.length > 0 ? (
                <div className="space-y-3">
                  {stats.recentActivity.slice(0, 5).map((activity: ActivityLog) => (
                    <div key={activity._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                          {getActivityIcon(activity.activityType)}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">
                            {typeof activity.user === 'object' ? activity.user.name : 'User'}
                          </p>
                          <p className="text-sm text-gray-500">{getActivityLabel(activity.activityType)}</p>
                        </div>
                      </div>
                      <span className="font-semibold text-green-600">+{activity.pointsEarned} pts</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">No recent activity</p>
              )}
            </CardContent>
          </Card>

          {/* Top Users */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-green-500" />
                  Top Users
                </CardTitle>
                <CardDescription>Highest earning users</CardDescription>
              </div>
              <Link to="/admin/users">
                <Button variant="ghost" size="sm">
                  View All
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {stats?.topUsers && stats.topUsers.length > 0 ? (
                <div className="space-y-3">
                  {stats.topUsers.map((user: User, index: number) => (
                    <div key={user._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-gradient-to-br from-[#007BFF] to-[#0056b3] text-white">
                            {user.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-gray-900">{user.name}</p>
                          <p className="text-sm text-gray-500">Rank #{user.rank}</p>
                        </div>
                      </div>
                      <div className="flex items-center text-[#FFD700]">
                        <Coins className="w-4 h-4 mr-1" />
                        <span className="font-semibold">{user.points.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">No users yet</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
