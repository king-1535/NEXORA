import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  User,
  Mail, 
  Coins, 
  Trophy, 
  Flame, 
  Star,
  Calendar,
  Edit2,
  Save,
  X,
  Loader2,
  CheckCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { userAPI } from '../services/api';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  const getBadgeColor = (badge: string) => {
    const colors: Record<string, string> = {
      starter: 'bg-gray-100 text-gray-700',
      explorer: 'bg-green-100 text-green-700',
      champion: 'bg-blue-100 text-blue-700',
      elite: 'bg-purple-100 text-purple-700',
      master: 'bg-orange-100 text-orange-700',
      legend: 'bg-yellow-100 text-yellow-700'
    };
    return colors[badge] || 'bg-gray-100 text-gray-700';
  };

  const handleSave = async () => {
    if (!name.trim()) {
      setError('Name is required');
      return;
    }

    setIsSaving(true);
    setError('');

    try {
      const response = await userAPI.updateProfile(name);
      if (response.data.success) {
        updateUser({ ...user!, name });
        setIsEditing(false);
        toast.success('Profile updated successfully');
      }
    } catch (error: any) {
      setError(error.response?.data?.message || 'Failed to update profile');
      toast.error('Failed to update profile');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setName(user?.name || '');
    setIsEditing(false);
    setError('');
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Your Profile</h1>
          <p className="text-gray-600 mt-1">
            Manage your account and view your achievements
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6 text-center">
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarFallback className="bg-gradient-to-br from-[#007BFF] to-[#0056b3] text-white text-3xl font-bold">
                    {user.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>

                {isEditing ? (
                  <div className="space-y-3">
                    {error && (
                      <Alert variant="destructive">
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your name"
                    />
                    <div className="flex space-x-2">
                      <Button
                        onClick={handleSave}
                        disabled={isSaving}
                        className="flex-1"
                      >
                        {isSaving ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <Save className="w-4 h-4 mr-1" />
                            Save
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={handleCancel}
                        variant="outline"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>
                    <p className="text-gray-500 flex items-center justify-center mt-1">
                      <Mail className="w-4 h-4 mr-1" />
                      {user.email}
                    </p>
                    <div className="mt-4">
                      <Badge className={user.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}>
                        {user.role === 'admin' ? 'Administrator' : 'Member'}
                      </Badge>
                    </div>
                    <Button
                      onClick={() => setIsEditing(true)}
                      variant="outline"
                      className="mt-4 w-full"
                    >
                      <Edit2 className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                  </>
                )}

                <div className="mt-6 pt-6 border-t">
                  <p className="text-sm text-gray-500 flex items-center justify-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    Member since {new Date(user.createdAt || '').toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Badges */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="w-5 h-5 mr-2 text-[#FFD700]" />
                  Your Badges
                </CardTitle>
              </CardHeader>
              <CardContent>
                {user.badges && user.badges.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {user.badges.map((badge: string) => (
                      <Badge key={badge} className={`${getBadgeColor(badge)} px-3 py-1 capitalize`}>
                        {badge}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-4">
                    Complete surveys to earn badges!
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Stats & Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <Coins className="w-8 h-8 mx-auto mb-2 text-[#FFD700]" />
                  <p className="text-2xl font-bold text-gray-900">{user.points}</p>
                  <p className="text-sm text-gray-500">Total Points</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Trophy className="w-8 h-8 mx-auto mb-2 text-[#007BFF]" />
                  <p className="text-2xl font-bold text-gray-900">#{user.rank}</p>
                  <p className="text-sm text-gray-500">Current Rank</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <Flame className="w-8 h-8 mx-auto mb-2 text-orange-500" />
                  <p className="text-2xl font-bold text-gray-900">{user.streak}</p>
                  <p className="text-sm text-gray-500">Day Streak</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-500" />
                  <p className="text-2xl font-bold text-gray-900">{user.completedSurveys?.length || 0}</p>
                  <p className="text-sm text-gray-500">Surveys Done</p>
                </CardContent>
              </Card>
            </div>

            {/* Account Info */}
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>
                  Your account details and settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b">
                  <div className="flex items-center">
                    <User className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-600">Full Name</span>
                  </div>
                  <span className="font-medium">{user.name}</span>
                </div>
                <div className="flex items-center justify-between py-3 border-b">
                  <div className="flex items-center">
                    <Mail className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-600">Email Address</span>
                  </div>
                  <span className="font-medium">{user.email}</span>
                </div>
                <div className="flex items-center justify-between py-3 border-b">
                  <div className="flex items-center">
                    <Star className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-600">Account Type</span>
                  </div>
                  <Badge className={user.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}>
                    {user.role === 'admin' ? 'Administrator' : 'Standard User'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between py-3">
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-gray-400 mr-3" />
                    <span className="text-gray-600">Email Verification</span>
                  </div>
                  <Badge className="bg-green-100 text-green-700">
                    Verified
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Security */}
            <Card>
              <CardHeader>
                <CardTitle>Security</CardTitle>
                <CardDescription>
                  Manage your account security
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">Password</p>
                    <p className="text-sm text-gray-500">Last changed recently</p>
                  </div>
                  <Button variant="outline">
                    Change Password
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
