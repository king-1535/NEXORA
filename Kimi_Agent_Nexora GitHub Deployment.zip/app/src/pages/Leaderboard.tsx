import { useEffect, useState } from 'react';
import { userAPI } from '../services/api';
import type { LeaderboardEntry } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Trophy, 
  Medal, 
  Award, 
  Crown,
  Flame,
  Coins,
  TrendingUp,
  Loader2,
  Star
} from 'lucide-react';
import { toast } from 'sonner';

export default function Leaderboard() {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [currentUser, setCurrentUser] = useState<{ rank: number; points: number; name: string } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    fetchLeaderboard();
  }, [activeTab]);

  const fetchLeaderboard = async () => {
    try {
      setIsLoading(true);
      const response = await userAPI.getLeaderboard({ 
        period: activeTab,
        limit: 10 
      });
      if (response.data.success) {
        setLeaderboard(response.data.data.leaderboard);
        setCurrentUser(response.data.data.currentUser);
      }
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
      toast.error('Failed to load leaderboard');
    } finally {
      setIsLoading(false);
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-[#FFD700]" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-orange-500" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center font-semibold text-gray-500">{rank}</span>;
    }
  };

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-100 to-yellow-200 border-yellow-300';
      case 2:
        return 'bg-gradient-to-r from-gray-100 to-gray-200 border-gray-300';
      case 3:
        return 'bg-gradient-to-r from-orange-100 to-orange-200 border-orange-300';
      default:
        return 'bg-white border-gray-200';
    }
  };

  const getBadgeColor = (badge: string) => {
    const colors: Record<string, string> = {
      starter: 'bg-gray-100 text-gray-700',
      explorer: 'bg-green-100 text-green-700',
      champion: 'bg-blue-100 text-blue-700',
      elite: 'bg-purple-100 text-purple-700',
      master: 'bg-orange-100 text-orange-700',
      legend: 'bg-yellow-100 text-yellow-700'
    };
    return colors[badge] || 'bg-gray-100 text-gray-700';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center">
            <Trophy className="w-8 h-8 mr-3 text-[#FFD700]" />
            Leaderboard
          </h1>
          <p className="text-gray-600 mt-2">
            Compete with other users and win amazing rewards!
          </p>
        </div>

        {/* Current User Stats */}
        {currentUser && (
          <Card className="mb-8 bg-gradient-to-br from-[#007BFF] to-[#0056b3] text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                    <span className="text-2xl font-bold">#{currentUser.rank}</span>
                  </div>
                  <div>
                    <p className="text-blue-100">Your Rank</p>
                    <p className="text-2xl font-bold">{currentUser.name}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-blue-100">Your Points</p>
                  <p className="text-3xl font-bold flex items-center">
                    <Coins className="w-6 h-6 mr-2 text-[#FFD700]" />
                    {currentUser.points.toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Rewards Info */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Star className="w-5 h-5 mr-2 text-[#FFD700]" />
              Weekly & Monthly Rewards
            </CardTitle>
            <CardDescription>
              Top performers win cash prizes every week and month!
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl">
                <Crown className="w-8 h-8 mx-auto mb-2 text-[#FFD700]" />
                <p className="text-2xl font-bold text-gray-900">$50</p>
                <p className="text-sm text-gray-600">1st Place</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl">
                <Medal className="w-8 h-8 mx-auto mb-2 text-gray-500" />
                <p className="text-2xl font-bold text-gray-900">$30</p>
                <p className="text-sm text-gray-600">2nd Place</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl">
                <Award className="w-8 h-8 mx-auto mb-2 text-orange-500" />
                <p className="text-2xl font-bold text-gray-900">$20</p>
                <p className="text-sm text-gray-600">3rd Place</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Leaderboard Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="all">All Time</TabsTrigger>
            <TabsTrigger value="monthly">Monthly</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="capitalize">{activeTab} Rankings</span>
                  <TrendingUp className="w-5 h-5 text-green-500" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                {leaderboard.length > 0 ? (
                  <div className="space-y-3">
                    {leaderboard.map((entry) => (
                      <div
                        key={entry.rank}
                        className={`flex items-center p-4 rounded-xl border-2 ${getRankStyle(entry.rank)} ${
                          currentUser?.name === entry.user.name ? 'ring-2 ring-[#007BFF]' : ''
                        }`}
                      >
                        <div className="flex items-center justify-center w-12">
                          {getRankIcon(entry.rank)}
                        </div>
                        
                        <Avatar className="h-12 w-12 ml-4">
                          <AvatarFallback className="bg-gradient-to-br from-[#007BFF] to-[#0056b3] text-white font-semibold">
                            {entry.user.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>

                        <div className="ml-4 flex-1">
                          <div className="flex items-center space-x-2">
                            <p className="font-semibold text-gray-900">{entry.user.name}</p>
                            {entry.user.badges.length > 0 && (
                              <Badge className={`${getBadgeColor(entry.user.badges[entry.user.badges.length - 1])} text-xs`}>
                                {entry.user.badges[entry.user.badges.length - 1]}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center text-sm text-gray-500">
                            <Coins className="w-4 h-4 mr-1 text-[#FFD700]" />
                            {entry.points.toLocaleString()} points
                          </div>
                        </div>

                        {entry.rank <= 3 && (
                          <div className="text-right">
                            <Badge className={
                              entry.rank === 1 ? 'bg-yellow-500' :
                              entry.rank === 2 ? 'bg-gray-500' :
                              'bg-orange-500'
                            }>
                              ${entry.rank === 1 ? 50 : entry.rank === 2 ? 30 : 20}
                            </Badge>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Trophy className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No rankings yet</h3>
                    <p className="text-gray-500">
                      Be the first to complete surveys and earn points!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Tips */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Flame className="w-5 h-5 mr-2 text-orange-500" />
              How to Climb the Ranks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold">1</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Complete Surveys</p>
                  <p className="text-sm text-gray-500">Earn 50-150 points per survey</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold">2</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Daily Login</p>
                  <p className="text-sm text-gray-500">Get 10 points + streak bonus</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-600 font-bold">3</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">Maintain Streak</p>
                  <p className="text-sm text-gray-500">Up to 20 bonus points daily</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
