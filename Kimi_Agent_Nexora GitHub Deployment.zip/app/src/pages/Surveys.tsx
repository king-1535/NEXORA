import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { surveyAPI } from '../services/api';
import type { Survey } from '../types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ClipboardList, 
  Clock, 
  Coins, 
  CheckCircle, 
  ArrowRight,
  Loader2,
  Filter
} from 'lucide-react';
import { toast } from 'sonner';

export default function Surveys() {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    fetchSurveys();
  }, [activeTab]);

  const fetchSurveys = async () => {
    try {
      setIsLoading(true);
      const params: any = { status: 'active' };
      if (activeTab !== 'all') {
        params.type = activeTab;
      }
      const response = await surveyAPI.getSurveys(params);
      if (response.data.success) {
        setSurveys(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching surveys:', error);
      toast.error('Failed to load surveys');
    } finally {
      setIsLoading(false);
    }
  };

  const getSurveyDuration = (type: string) => {
    return type === 'short' ? '2-3 min' : '5-10 min';
  };

  const getSurveyQuestions = (type: string) => {
    return type === 'short' ? '3-5 questions' : '10-15 questions';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Available Surveys</h1>
          <p className="text-gray-600 mt-1">
            Complete surveys to earn points and climb the leaderboard!
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100">Short Surveys</p>
                  <p className="text-2xl font-bold">
                    {surveys.filter(s => s.type === 'short' && !s.isCompleted).length} Available
                  </p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <ClipboardList className="w-6 h-6" />
                </div>
              </div>
              <p className="text-sm text-blue-100 mt-2">Earn 50 points each</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Long Surveys</p>
                  <p className="text-2xl font-bold">
                    {surveys.filter(s => s.type === 'long' && !s.isCompleted).length} Available
                  </p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <ClipboardList className="w-6 h-6" />
                </div>
              </div>
              <p className="text-sm text-purple-100 mt-2">Earn 150 points each</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100">Total Points Available</p>
                  <p className="text-2xl font-bold">
                    {surveys.filter(s => !s.isCompleted).reduce((acc, s) => acc + s.points, 0)} pts
                  </p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <Coins className="w-6 h-6" />
                </div>
              </div>
              <p className="text-sm text-green-100 mt-2">Complete all to earn max!</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="all">All Surveys</TabsTrigger>
              <TabsTrigger value="short">Short</TabsTrigger>
              <TabsTrigger value="long">Long</TabsTrigger>
            </TabsList>
            <div className="flex items-center text-sm text-gray-500">
              <Filter className="w-4 h-4 mr-1" />
              {surveys.length} surveys found
            </div>
          </div>

          <TabsContent value={activeTab} className="mt-0">
            {surveys.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {surveys.map((survey) => (
                  <Card key={survey._id} className={`card-hover ${survey.isCompleted ? 'opacity-60' : ''}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg">{survey.title}</CardTitle>
                          <CardDescription className="mt-1">
                            {survey.description || 'Share your opinion and earn points'}
                          </CardDescription>
                        </div>
                        {survey.isCompleted && (
                          <Badge className="bg-green-100 text-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Done
                          </Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 mb-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {getSurveyDuration(survey.type)}
                        </span>
                        <span className="flex items-center">
                          <ClipboardList className="w-4 h-4 mr-1" />
                          {getSurveyQuestions(survey.type)}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mb-4">
                        <Badge className={
                          survey.type === 'short' 
                            ? 'bg-blue-100 text-blue-700' 
                            : 'bg-purple-100 text-purple-700'
                        }>
                          {survey.type === 'short' ? 'Short Survey' : 'Long Survey'}
                        </Badge>
                        <div className="flex items-center text-[#FFD700]">
                          <Coins className="w-4 h-4 mr-1" />
                          <span className="font-semibold">{survey.points} pts</span>
                        </div>
                      </div>

                      {survey.isCompleted ? (
                        <Button disabled className="w-full" variant="outline">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Completed
                        </Button>
                      ) : (
                        <Link to={`/surveys/${survey._id}`}>
                          <Button className="w-full btn-primary">
                            Start Survey
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </Link>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <ClipboardList className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No surveys available</h3>
                  <p className="text-gray-500">
                    Check back later for new surveys! Complete your daily login to earn points.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
