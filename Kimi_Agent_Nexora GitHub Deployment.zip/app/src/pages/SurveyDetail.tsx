import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { surveyAPI } from '../services/api';
import type { Survey, Question } from '../types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Coins, 
  ArrowLeft,
  ArrowRight,
  CheckCircle,
  Loader2,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';

export default function SurveyDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [survey, setSurvey] = useState<Survey | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [showSummary, setShowSummary] = useState(false);

  useEffect(() => {
    if (id) {
      fetchSurvey(id);
    }
  }, [id]);

  const fetchSurvey = async (surveyId: string) => {
    try {
      const response = await surveyAPI.getSurvey(surveyId);
      if (response.data.success) {
        setSurvey(response.data.data);
      }
    } catch (error: any) {
      console.error('Error fetching survey:', error);
      toast.error(error.response?.data?.message || 'Failed to load survey');
      navigate('/surveys');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswer = (questionId: string, answer: any) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleNext = () => {
    if (survey && currentQuestion < survey.questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      setShowSummary(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
      setShowSummary(false);
    }
  };

  const handleSubmit = async () => {
    if (!survey) return;

    // Validate all questions answered
    const unansweredQuestions = survey.questions.filter((q: Question) => 
      q.required && !answers[q._id || '']
    );

    if (unansweredQuestions.length > 0) {
      toast.error('Please answer all required questions');
      setShowSummary(false);
      return;
    }

    setIsSubmitting(true);

    try {
      const formattedAnswers = survey.questions.map((q: Question) => ({
        questionId: q._id,
        answer: answers[q._id || '']
      }));

      const response = await surveyAPI.submitSurvey(survey._id, formattedAnswers);
      
      if (response.data.success) {
        toast.success('Survey completed!', {
          description: `You earned ${response.data.data.pointsEarned} points!`
        });
        navigate('/dashboard');
      }
    } catch (error: any) {
      console.error('Error submitting survey:', error);
      toast.error(error.response?.data?.message || 'Failed to submit survey');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderQuestion = (question: Question) => {
    const questionId = question._id || '';

    switch (question.questionType) {
      case 'single_choice':
        return (
          <RadioGroup
            value={answers[questionId] || ''}
            onValueChange={(value) => handleAnswer(questionId, value)}
            className="space-y-3"
          >
            {question.options?.map((option: string, index: number) => (
              <div key={index} className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-gray-50 cursor-pointer">
                <RadioGroupItem value={option} id={`${questionId}-${index}`} />
                <Label htmlFor={`${questionId}-${index}`} className="flex-1 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        );

      case 'multiple_choice':
        return (
          <div className="space-y-3">
            {question.options?.map((option: string, index: number) => (
              <div key={index} className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-gray-50">
                <Checkbox
                  id={`${questionId}-${index}`}
                  checked={(answers[questionId] || []).includes(option)}
                  onCheckedChange={(checked) => {
                    const currentAnswers = answers[questionId] || [];
                    if (checked) {
                      handleAnswer(questionId, [...currentAnswers, option]);
                    } else {
                      handleAnswer(questionId, currentAnswers.filter((a: string) => a !== option));
                    }
                  }}
                />
                <Label htmlFor={`${questionId}-${index}`} className="flex-1 cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </div>
        );

      case 'yes_no':
        return (
          <RadioGroup
            value={answers[questionId] || ''}
            onValueChange={(value) => handleAnswer(questionId, value)}
            className="flex space-x-4"
          >
            <div className="flex items-center space-x-2 p-4 rounded-lg border hover:bg-gray-50 cursor-pointer">
              <RadioGroupItem value="yes" id={`${questionId}-yes`} />
              <Label htmlFor={`${questionId}-yes`} className="cursor-pointer">Yes</Label>
            </div>
            <div className="flex items-center space-x-2 p-4 rounded-lg border hover:bg-gray-50 cursor-pointer">
              <RadioGroupItem value="no" id={`${questionId}-no`} />
              <Label htmlFor={`${questionId}-no`} className="cursor-pointer">No</Label>
            </div>
          </RadioGroup>
        );

      case 'rating':
        return (
          <RadioGroup
            value={answers[questionId] || ''}
            onValueChange={(value) => handleAnswer(questionId, parseInt(value))}
            className="flex space-x-2"
          >
            {[1, 2, 3, 4, 5].map((rating) => (
              <div key={rating} className="flex flex-col items-center">
                <RadioGroupItem
                  value={rating.toString()}
                  id={`${questionId}-${rating}`}
                  className="sr-only"
                />
                <Label
                  htmlFor={`${questionId}-${rating}`}
                  className={`w-12 h-12 rounded-lg flex items-center justify-center text-lg font-semibold cursor-pointer transition-colors ${
                    answers[questionId] === rating
                      ? 'bg-[#007BFF] text-white'
                      : 'bg-gray-100 hover:bg-gray-200'
                  }`}
                >
                  {rating}
                </Label>
              </div>
            ))}
          </RadioGroup>
        );

      case 'text':
        return (
          <Textarea
            value={answers[questionId] || ''}
            onChange={(e) => handleAnswer(questionId, e.target.value)}
            placeholder="Type your answer here..."
            className="min-h-[120px]"
          />
        );

      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  if (!survey) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Survey Not Found</h2>
            <p className="text-gray-500 mb-4">The survey you're looking for doesn't exist.</p>
            <Button onClick={() => navigate('/surveys')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Surveys
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showSummary) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="w-6 h-6 mr-2 text-green-500" />
                Review Your Answers
              </CardTitle>
              <CardDescription>
                Please review your answers before submitting
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {survey.questions.map((question: Question, index: number) => (
                <div key={question._id} className="border-b pb-4 last:border-0">
                  <p className="font-medium text-gray-900 mb-2">
                    {index + 1}. {question.questionText}
                  </p>
                  <p className="text-[#007BFF]">
                    {Array.isArray(answers[question._id || '']) 
                      ? answers[question._id || ''].join(', ')
                      : answers[question._id || ''] || 'Not answered'}
                  </p>
                </div>
              ))}

              <div className="flex space-x-4 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowSummary(false)}
                  className="flex-1"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="flex-1 btn-primary"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      Submit Survey
                      <Coins className="w-4 h-4 ml-2" />
                      {survey.points} pts
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const currentQ = survey.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / survey.questions.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/surveys')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Surveys
          </Button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{survey.title}</h1>
              <p className="text-gray-600 mt-1">{survey.description}</p>
            </div>
            <div className="flex items-center text-[#FFD700]">
              <Coins className="w-5 h-5 mr-1" />
              <span className="font-semibold">{survey.points} pts</span>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-500">
              Question {currentQuestion + 1} of {survey.questions.length}
            </span>
            <span className="text-sm text-gray-500">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">
              {currentQ.questionText}
              {currentQ.required && <span className="text-red-500 ml-1">*</span>}
            </CardTitle>
            {currentQ.questionType === 'multiple_choice' && (
              <CardDescription>Select all that apply</CardDescription>
            )}
          </CardHeader>
          <CardContent>
            {renderQuestion(currentQ)}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          <Button
            onClick={handleNext}
            disabled={currentQ.required && !answers[currentQ._id || '']}
            className="btn-primary"
          >
            {currentQuestion === survey.questions.length - 1 ? (
              <>
                Review
                <CheckCircle className="w-4 h-4 ml-2" />
              </>
            ) : (
              <>
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
