import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/api';
import type { DashboardData, ActivityLog } from '../types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Coins, 
  Trophy, 
  Flame, 
  ClipboardList, 
  ArrowRight,
  TrendingUp,
  Calendar,
  Star,
  Loader2,
  Gift
} from 'lucide-react';
import { toast } from 'sonner';

export default function Dashboard() {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await userAPI.getDashboard();
      if (response.data.success) {
        setDashboardData(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching dashboard:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  const getBadgeColor = (badge: string) => {
    const colors: Record<string, string> = {
      starter: 'bg-gray-100 text-gray-700',
      explorer: 'bg-green-100 text-green-700',
      champion: 'bg-blue-100 text-blue-700',
      elite: 'bg-purple-100 text-purple-700',
      master: 'bg-orange-100 text-orange-700',
      legend: 'bg-yellow-100 text-yellow-700'
    };
    return colors[badge] || 'bg-gray-100 text-gray-700';
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'survey_completion':
        return <ClipboardList className="w-4 h-4 text-blue-500" />;
      case 'daily_login':
        return <Calendar className="w-4 h-4 text-green-500" />;
      case 'streak_bonus':
        return <Flame className="w-4 h-4 text-orange-500" />;
      case 'reward_claimed':
        return <Gift className="w-4 h-4 text-purple-500" />;
      default:
        return <Star className="w-4 h-4 text-gray-500" />;
    }
  };

  const getActivityLabel = (type: string) => {
    const labels: Record<string, string> = {
      survey_completion: 'Survey Completed',
      daily_login: 'Daily Login',
      streak_bonus: 'Streak Bonus',
      reward_claimed: 'Reward Claimed',
      admin_adjustment: 'Admin Adjustment'
    };
    return labels[type] || type;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#007BFF]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-gray-600 mt-1">
            Here's your progress and available activities for today.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Points</p>
                  <p className="text-3xl font-bold text-gray-900">{dashboardData?.user.points || 0}</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                  <Coins className="w-6 h-6 text-[#FFD700]" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span>Keep earning!</span>
              </div>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Current Rank</p>
                  <p className="text-3xl font-bold text-gray-900">#{dashboardData?.user.rank || 0}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-[#007BFF]" />
                </div>
              </div>
              <div className="mt-4">
                <Link to="/leaderboard" className="text-sm text-[#007BFF] hover:underline flex items-center">
                  View Leaderboard
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Daily Streak</p>
                  <p className="text-3xl font-bold text-gray-900">{dashboardData?.user.streak || 0} days</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Flame className="w-6 h-6 text-orange-500" />
                </div>
              </div>
              <div className="mt-4 text-sm text-gray-500">
                {dashboardData?.user.streak && dashboardData.user.streak > 1 
                  ? `+${Math.min(dashboardData.user.streak * 2, 20)} bonus points!` 
                  : 'Login daily for bonuses!'}
              </div>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Surveys Done</p>
                  <p className="text-3xl font-bold text-gray-900">{dashboardData?.user.completedSurveysCount || 0}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <ClipboardList className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4">
                <Link to="/surveys" className="text-sm text-[#007BFF] hover:underline flex items-center">
                  Take More Surveys
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Next Badge Progress */}
            {dashboardData?.nextBadge && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="w-5 h-5 mr-2 text-[#FFD700]" />
                    Next Badge Progress
                  </CardTitle>
                  <CardDescription>
                    Earn {dashboardData.nextBadge.threshold} points to unlock the {dashboardData.nextBadge.name} badge
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Current: {dashboardData.user.points} pts</span>
                    <span className="text-sm text-gray-600">Target: {dashboardData.nextBadge.threshold} pts</span>
                  </div>
                  <Progress value={dashboardData.progressToNext} className="h-3" />
                  <p className="text-sm text-gray-500 mt-2">
                    {Math.round(dashboardData.progressToNext)}% complete
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Badges */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-[#FFD700]" />
                  Your Badges
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dashboardData?.user.badges && dashboardData.user.badges.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {dashboardData.user.badges.map((badge: string) => (
                      <Badge key={badge} className={`${getBadgeColor(badge)} px-3 py-1 capitalize`}>
                        {badge}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">Complete surveys to earn your first badge!</p>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-[#007BFF]" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dashboardData?.recentActivity && dashboardData.recentActivity.length > 0 ? (
                  <div className="space-y-4">
                    {dashboardData.recentActivity.slice(0, 5).map((activity: ActivityLog) => (
                      <div key={activity._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                            {getActivityIcon(activity.activityType)}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{getActivityLabel(activity.activityType)}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(activity.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <span className="font-semibold text-green-600">+{activity.pointsEarned} pts</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No recent activity. Start completing surveys!</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link to="/surveys">
                  <Button className="w-full btn-primary">
                    <ClipboardList className="w-4 h-4 mr-2" />
                    Take a Survey
                  </Button>
                </Link>
                <Link to="/leaderboard">
                  <Button variant="outline" className="w-full">
                    <Trophy className="w-4 h-4 mr-2" />
                    View Leaderboard
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Activity Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Activity Summary (30 days)</CardTitle>
              </CardHeader>
              <CardContent>
                {dashboardData?.activitySummary && dashboardData.activitySummary.length > 0 ? (
                  <div className="space-y-3">
                    {dashboardData.activitySummary.map((summary: any) => (
                      <div key={summary._id} className="flex items-center justify-between">
                        <span className="text-gray-600">{getActivityLabel(summary._id)}</span>
                        <div className="text-right">
                          <span className="font-semibold text-gray-900">{summary.count}</span>
                          <span className="text-sm text-gray-500 ml-2">({summary.totalPoints} pts)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No activity in the last 30 days.</p>
                )}
              </CardContent>
            </Card>

            {/* Rewards */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Gift className="w-5 h-5 mr-2 text-purple-500" />
                  Recent Rewards
                </CardTitle>
              </CardHeader>
              <CardContent>
                {dashboardData?.rewards && dashboardData.rewards.length > 0 ? (
                  <div className="space-y-3">
                    {dashboardData.rewards.map((reward: any) => (
                      <div key={reward._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">${reward.amount}</p>
                          <p className="text-sm text-gray-500 capitalize">{reward.period} Reward</p>
                        </div>
                        <Badge className={
                          reward.status === 'paid' ? 'bg-green-100 text-green-700' :
                          reward.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-gray-100 text-gray-700'
                        }>
                          {reward.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No rewards yet. Keep earning points!</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
