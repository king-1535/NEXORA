import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '@/components/ui/button';
import {
  Coins,
  Trophy,
  ClipboardList,
  Flame,
  Star,
  Gift,
  CheckCircle,
  ArrowRight,
  Zap,
  Shield
} from 'lucide-react';

export default function Home() {
  const { isAuthenticated } = useAuth();

  const features = [
    {
      icon: ClipboardList,
      title: 'Complete Surveys',
      description: 'Answer short and long surveys on various topics and earn points instantly.',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: Flame,
      title: 'Daily Streaks',
      description: 'Log in daily to build your streak and earn bonus points every day.',
      color: 'bg-orange-100 text-orange-600'
    },
    {
      icon: Trophy,
      title: 'Compete & Win',
      description: 'Climb the leaderboard and compete with other users for top rewards.',
      color: 'bg-yellow-100 text-yellow-600'
    },
    {
      icon: Gift,
      title: 'Real Rewards',
      description: 'Convert your points to real cash rewards. Weekly and monthly payouts.',
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: Star,
      title: 'Earn Badges',
      description: 'Unlock achievement badges as you reach new milestones.',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      icon: Shield,
      title: 'Secure & Trusted',
      description: 'Your data is safe with us. We use bank-level security.',
      color: 'bg-red-100 text-red-600'
    }
  ];

  const howItWorks = [
    {
      step: 1,
      title: 'Sign Up Free',
      description: 'Create your free account in seconds. No credit card required.'
    },
    {
      step: 2,
      title: 'Complete Tasks',
      description: 'Take surveys, complete daily check-ins, and earn points.'
    },
    {
      step: 3,
      title: 'Earn Rewards',
      description: 'Redeem your points for real cash rewards. Get paid weekly!'
    }
  ];

  const rewards = [
    { rank: 1, amount: 50, label: '1st Place', color: 'from-yellow-400 to-yellow-600' },
    { rank: 2, amount: 30, label: '2nd Place', color: 'from-gray-300 to-gray-500' },
    { rank: 3, amount: 20, label: '3rd Place', color: 'from-orange-400 to-orange-600' }
  ];

  const testimonials = [
    {
      name: 'Sarah M.',
      role: 'Top Earner',
      content: 'I\'ve earned over $500 in just 3 months! Nexora is legit and pays on time.',
      avatar: 'S'
    },
    {
      name: 'John D.',
      role: 'Regular User',
      content: 'Great way to make extra cash in my free time. The surveys are interesting too!',
      avatar: 'J'
    },
    {
      name: 'Emily R.',
      role: 'Champion Badge',
      content: 'Love the gamification! Earning badges keeps me motivated to participate daily.',
      avatar: 'E'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-48 h-48 bg-yellow-400 rounded-full blur-3xl"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
                <Zap className="w-4 h-4 text-[#FFD700]" />
                <span className="text-sm font-medium">Earn up to $50/week!</span>
              </div>
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight mb-6">
                Earn Rewards by{' '}
                <span className="text-[#FFD700]">Sharing Your Opinion</span>
              </h1>
              <p className="text-xl text-blue-100 mb-8 max-w-lg">
                Join thousands of users earning real cash by completing surveys, 
                building daily streaks, and competing on the leaderboard.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                {isAuthenticated ? (
                  <Link to="/dashboard">
                    <Button size="lg" className="btn-secondary text-lg px-8">
                      Go to Dashboard
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                ) : (
                  <>
                    <Link to="/register">
                      <Button size="lg" className="btn-secondary text-lg px-8">
                        Start Earning Now
                        <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>
                    </Link>
                    <Link to="/login">
                      <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 text-lg px-8">
                        Sign In
                      </Button>
                    </Link>
                  </>
                )}
              </div>
              <div className="flex items-center space-x-6 mt-8">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-sm">Free to Join</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-sm">Instant Payouts</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-sm">Trusted by 10K+ Users</span>
                </div>
              </div>
            </div>
            
            <div className="hidden lg:block animate-slide-up">
              <div className="relative">
                <div className="bg-white rounded-2xl shadow-2xl p-6 transform rotate-3 hover:rotate-0 transition-transform duration-300">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-full flex items-center justify-center text-white font-bold">
                        J
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">John Doe</p>
                        <p className="text-sm text-gray-500">Explorer</p>
                      </div>
                    </div>
                    <div className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                      +150 pts
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total Points</span>
                      <span className="font-bold text-xl text-gray-900">2,450</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-gradient-to-r from-[#007BFF] to-[#FFD700] h-2 rounded-full" style={{ width: '65%' }}></div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Daily Streak</span>
                      <span className="font-bold text-orange-500 flex items-center">
                        <Flame className="w-4 h-4 mr-1" />
                        12 days
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-4 transform -rotate-6">
                  <div className="flex items-center space-x-2">
                    <Trophy className="w-8 h-8 text-[#FFD700]" />
                    <div>
                      <p className="font-semibold text-gray-900">Rank #42</p>
                      <p className="text-xs text-gray-500">Top 5%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { label: 'Active Users', value: '10,000+', icon: Coins },
              { label: 'Surveys Completed', value: '500K+', icon: ClipboardList },
              { label: 'Rewards Paid', value: '$100K+', icon: Gift },
              { label: 'Avg. Rating', value: '4.8/5', icon: Star }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-xl mb-3">
                  <stat.icon className="w-6 h-6 text-[#007BFF]" />
                </div>
                <p className="text-2xl lg:text-3xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-gray-500">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Why Choose <span className="text-[#007BFF]">Nexora</span>?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We offer the best rewards program with multiple ways to earn and instant payouts.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-shadow duration-300"
              >
                <div className={`inline-flex items-center justify-center w-14 h-14 ${feature.color} rounded-xl mb-4`}>
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              How It <span className="text-[#007BFF]">Works</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Getting started is easy. Follow these simple steps to start earning.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {howItWorks.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-2xl p-8 text-white text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold">{step.step}</span>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-blue-100">{step.description}</p>
                </div>
                {index < howItWorks.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="w-8 h-8 text-gray-300" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Rewards Section */}
      <section id="rewards" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Weekly & Monthly <span className="text-[#FFD700]">Rewards</span>
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Compete with other users and win big cash prizes every week and month!
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {rewards.map((reward, index) => (
              <div
                key={index}
                className={`relative bg-gradient-to-br ${reward.color} rounded-2xl p-8 text-center transform ${
                  index === 0 ? 'scale-110 z-10' : 'scale-100'
                }`}
              >
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-white text-gray-900 px-4 py-1 rounded-full text-sm font-bold">
                    {reward.label}
                  </div>
                </div>
                <Trophy className="w-12 h-12 mx-auto mb-4 text-white/80" />
                <p className="text-5xl font-bold mb-2">${reward.amount}</p>
                <p className="text-white/80">Cash Prize</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <p className="text-gray-400 mb-4">Plus rewards for ranks 4-10!</p>
            {!isAuthenticated && (
              <Link to="/register">
                <Button size="lg" className="btn-secondary text-lg px-8">
                  Start Competing Now
                </Button>
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              What Our <span className="text-[#007BFF]">Users Say</span>
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm">
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-[#FFD700] fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6">"{testimonial.content}"</p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-full flex items-center justify-center text-white font-semibold">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-[#007BFF] to-[#0056b3]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Start Earning?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of users already earning rewards with Nexora. 
            It's free to get started!
          </p>
          {!isAuthenticated ? (
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="bg-white text-[#007BFF] hover:bg-gray-100 text-lg px-8">
                  Create Free Account
                </Button>
              </Link>
              <Link to="/login">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 text-lg px-8">
                  Sign In
                </Button>
              </Link>
            </div>
          ) : (
            <Link to="/dashboard">
              <Button size="lg" className="bg-white text-[#007BFF] hover:bg-gray-100 text-lg px-8">
                Go to Dashboard
              </Button>
            </Link>
          )}
        </div>
      </section>
    </div>
  );
}
