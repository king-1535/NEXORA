import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Trophy,
  ClipboardList,
  LayoutDashboard,
  User,
  LogOut,
  Menu,
  Shield,
  Coins,
  Flame
} from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAdmin = user?.role === 'admin';

  const navLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, auth: true },
    { path: '/surveys', label: 'Surveys', icon: ClipboardList, auth: true },
    { path: '/leaderboard', label: 'Leaderboard', icon: Trophy, auth: true },
  ];

  const adminLinks = [
    { path: '/admin', label: 'Admin Dashboard', icon: Shield },
    { path: '/admin/users', label: 'Manage Users', icon: User },
    { path: '/admin/surveys', label: 'Manage Surveys', icon: ClipboardList },
    { path: '/admin/rewards', label: 'Rewards', icon: Coins },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-lg flex items-center justify-center">
                <Coins className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold gradient-text">Nexora</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {isAuthenticated ? (
              <>
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center space-x-1 px-4 py-2 rounded-lg transition-colors ${
                      isActive(link.path)
                        ? 'bg-blue-50 text-[#007BFF]'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <link.icon className="w-4 h-4" />
                    <span>{link.label}</span>
                  </Link>
                ))}

                {/* Points & Streak Display */}
                <div className="flex items-center space-x-3 ml-4 mr-2">
                  <div className="flex items-center space-x-1 bg-yellow-50 px-3 py-1 rounded-full">
                    <Coins className="w-4 h-4 text-[#FFD700]" />
                    <span className="font-semibold text-gray-700">{user?.points || 0}</span>
                  </div>
                  <div className="flex items-center space-x-1 bg-orange-50 px-3 py-1 rounded-full">
                    <Flame className="w-4 h-4 text-orange-500" />
                    <span className="font-semibold text-gray-700">{user?.streak || 0}</span>
                  </div>
                </div>

                {/* User Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                      <div className="w-10 h-10 bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-full flex items-center justify-center text-white font-semibold">
                        {user?.name?.charAt(0).toUpperCase()}
                      </div>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-3 py-2">
                      <p className="font-semibold">{user?.name}</p>
                      <p className="text-sm text-gray-500">{user?.email}</p>
                      {isAdmin && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800 mt-1">
                          Admin
                        </span>
                      )}
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link to="/profile" className="cursor-pointer">
                        <User className="w-4 h-4 mr-2" />
                        Profile
                      </Link>
                    </DropdownMenuItem>
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <div className="px-3 py-1 text-xs font-semibold text-gray-500">
                          Admin
                        </div>
                        {adminLinks.map((link) => (
                          <DropdownMenuItem key={link.path} asChild>
                            <Link to={link.path} className="cursor-pointer">
                              <link.icon className="w-4 h-4 mr-2" />
                              {link.label}
                            </Link>
                          </DropdownMenuItem>
                        ))}
                      </>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="cursor-pointer text-red-600">
                      <LogOut className="w-4 h-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center space-x-3">
                <Link to="/login">
                  <Button variant="ghost">Login</Button>
                </Link>
                <Link to="/register">
                  <Button className="btn-primary">Get Started</Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="w-6 h-6" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-3 space-y-2">
            {isAuthenticated ? (
              <>
                <div className="flex items-center space-x-3 pb-3 border-b">
                  <div className="w-10 h-10 bg-gradient-to-br from-[#007BFF] to-[#0056b3] rounded-full flex items-center justify-center text-white font-semibold">
                    {user?.name?.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold">{user?.name}</p>
                    <div className="flex items-center space-x-3 text-sm">
                      <span className="flex items-center">
                        <Coins className="w-3 h-3 mr-1 text-[#FFD700]" />
                        {user?.points}
                      </span>
                      <span className="flex items-center">
                        <Flame className="w-3 h-3 mr-1 text-orange-500" />
                        {user?.streak}
                      </span>
                    </div>
                  </div>
                </div>
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-lg ${
                      isActive(link.path)
                        ? 'bg-blue-50 text-[#007BFF]'
                        : 'text-gray-600'
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <link.icon className="w-5 h-5" />
                    <span>{link.label}</span>
                  </Link>
                ))}
                {isAdmin && (
                  <>
                    <div className="pt-2 border-t">
                      <p className="px-3 text-xs font-semibold text-gray-500 mb-1">Admin</p>
                      {adminLinks.map((link) => (
                        <Link
                          key={link.path}
                          to={link.path}
                          className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-600"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          <link.icon className="w-5 h-5" />
                          <span>{link.label}</span>
                        </Link>
                      ))}
                    </div>
                  </>
                )}
                <button
                  onClick={logout}
                  className="flex items-center space-x-2 px-3 py-2 rounded-lg text-red-600 w-full"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <div className="space-y-2">
                <Link
                  to="/login"
                  className="block px-3 py-2 rounded-lg text-gray-600"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="block px-3 py-2 rounded-lg bg-[#007BFF] text-white text-center"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Get Started
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
