import axios from 'axios';
import type { AxiosInstance, AxiosError } from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (name: string, email: string, password: string) =>
    api.post('/auth/register', { name, email, password }),
  
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  
  getMe: () =>
    api.get('/auth/me'),
  
  verifyEmail: (token: string) =>
    api.get(`/auth/verify/${token}`),
  
  resendVerification: (email: string) =>
    api.post('/auth/resend-verification', { email }),
  
  forgotPassword: (email: string) =>
    api.post('/auth/forgot-password', { email }),
  
  resetPassword: (token: string, password: string) =>
    api.put(`/auth/reset-password/${token}`, { password })
};

// Survey API
export const surveyAPI = {
  getSurveys: (params?: { type?: string; status?: string }) =>
    api.get('/surveys', { params }),
  
  getSurvey: (id: string) =>
    api.get(`/surveys/${id}`),
  
  createSurvey: (data: any) =>
    api.post('/surveys', data),
  
  updateSurvey: (id: string, data: any) =>
    api.put(`/surveys/${id}`, data),
  
  deleteSurvey: (id: string) =>
    api.delete(`/surveys/${id}`),
  
  submitSurvey: (id: string, answers: any[]) =>
    api.post(`/surveys/${id}/submit`, { answers }),
  
  getSurveyStats: () =>
    api.get('/surveys/stats/overview')
};

// User API
export const userAPI = {
  getDashboard: () =>
    api.get('/users/dashboard'),
  
  getActivityLog: (params?: { page?: number; limit?: number }) =>
    api.get('/users/activity', { params }),
  
  getLeaderboard: (params?: { period?: string; limit?: number }) =>
    api.get('/users/leaderboard', { params }),
  
  updateProfile: (name: string) =>
    api.put('/users/profile', { name }),
  
  getAllUsers: (params?: { page?: number; limit?: number; search?: string; sortBy?: string; order?: string }) =>
    api.get('/users', { params }),
  
  getUserById: (id: string) =>
    api.get(`/users/${id}`),
  
  updateUser: (id: string, data: any) =>
    api.put(`/users/${id}`, data),
  
  deleteUser: (id: string) =>
    api.delete(`/users/${id}`),
  
  adjustPoints: (id: string, points: number, reason?: string) =>
    api.post(`/users/${id}/adjust-points`, { points, reason }),
  
  exportUsers: () =>
    api.get('/admin/export/users')
};

// Admin API
export const adminAPI = {
  getDashboardStats: () =>
    api.get('/admin/dashboard'),
  
  getRewards: (params?: { status?: string; period?: string; page?: number; limit?: number }) =>
    api.get('/admin/rewards', { params }),
  
  updateReward: (id: string, data: any) =>
    api.put(`/admin/rewards/${id}`, data),
  
  calculateRewards: (period: string, startDate: string, endDate: string) =>
    api.post('/admin/rewards/calculate', { period, startDate, endDate }),
  
  getActivityLogs: (params?: { userId?: string; activityType?: string; page?: number; limit?: number }) =>
    api.get('/admin/activity-logs', { params }),
  
  exportUsers: () =>
    api.get('/admin/export/users'),
  
  getSettings: () =>
    api.get('/admin/settings'),
  
  createAdmin: (name: string, email: string, password: string) =>
    api.post('/admin/create-admin', { name, email, password })
};

export default api;
