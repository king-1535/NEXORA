# Nexora - Gamified Survey Platform

Nexora is a full-stack gamified survey and micro-task platform where users earn points by completing surveys and daily activities, compete on a leaderboard, and receive real cash rewards.

## Features

### User Features
- **Authentication**: Secure signup/login with JWT tokens
- **Dashboard**: View points, rank, streak, and activity history
- **Surveys**: Complete short (50 pts) and long (150 pts) surveys
- **Daily Login**: Earn 10 points + streak bonuses
- **Leaderboard**: Compete with others for weekly/monthly rewards
- **Badges**: Unlock achievement badges as you progress
- **Rewards**: Win cash prizes ($50, $30, $20 for top 3)

### Admin Features
- **Dashboard**: Platform overview with statistics
- **User Management**: View, edit, delete users, adjust points
- **Survey Management**: Create, edit, delete surveys
- **Reward Management**: Process and track reward payments
- **Activity Logs**: Monitor all user activities
- **Data Export**: Export user data

## Tech Stack

### Frontend
- React 19 + TypeScript
- Vite (build tool)
- Tailwind CSS
- shadcn/ui components
- React Router DOM
- Axios

### Backend
- Node.js + Express
- MongoDB + Mongoose
- JWT Authentication
- bcryptjs (password hashing)
- Express Validator

## Project Structure

```
nexora/
├── backend/              # Node.js backend
│   ├── config/          # Database configuration
│   ├── src/
│   │   ├── controllers/ # Route controllers
│   │   ├── middleware/  # Auth & error handlers
│   │   ├── models/      # MongoDB models
│   │   └── routes/      # API routes
│   ├── server.js        # Entry point
│   └── package.json
├── src/                 # React frontend
│   ├── components/      # Reusable components
│   ├── context/         # React context
│   ├── pages/           # Page components
│   ├── services/        # API services
│   └── types/           # TypeScript types
└── package.json
```

## Getting Started

### Prerequisites
- Node.js 18+ 
- MongoDB (local or Atlas)
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd nexora
```

2. **Install frontend dependencies**
```bash
npm install
```

3. **Install backend dependencies**
```bash
cd backend
npm install
cd ..
```

4. **Set up environment variables**

Frontend (.env):
```env
VITE_API_URL=http://localhost:5000/api
```

Backend (backend/.env):
```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/nexora
JWT_SECRET=your_super_secret_jwt_key_here
JWT_EXPIRE=30d
```

5. **Start MongoDB** (if using local)
```bash
mongod
```

6. **Run the application**

Terminal 1 - Backend:
```bash
cd backend
npm run dev
```

Terminal 2 - Frontend:
```bash
npm run dev
```

7. **Open in browser**
```
http://localhost:5173
```

## Demo Credentials

### Admin Account
- Email: `admin@nexora.com`
- Password: `admin123456`

### User Account (create via registration)
- Email: `user@example.com`
- Password: `user123456`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user
- `GET /api/auth/verify/:token` - Verify email

### Surveys
- `GET /api/surveys` - Get all surveys
- `GET /api/surveys/:id` - Get single survey
- `POST /api/surveys` - Create survey (Admin)
- `PUT /api/surveys/:id` - Update survey (Admin)
- `DELETE /api/surveys/:id` - Delete survey (Admin)
- `POST /api/surveys/:id/submit` - Submit survey response

### Users
- `GET /api/users/dashboard` - Get user dashboard
- `GET /api/users/activity` - Get activity log
- `GET /api/users/leaderboard` - Get leaderboard
- `GET /api/users` - Get all users (Admin)
- `PUT /api/users/:id` - Update user (Admin)
- `DELETE /api/users/:id` - Delete user (Admin)
- `POST /api/users/:id/adjust-points` - Adjust points (Admin)

### Admin
- `GET /api/admin/dashboard` - Get admin stats
- `GET /api/admin/rewards` - Get all rewards
- `PUT /api/admin/rewards/:id` - Update reward status
- `GET /api/admin/activity-logs` - Get activity logs
- `GET /api/admin/export/users` - Export users

## Point System

| Activity | Points |
|----------|--------|
| Daily Login | 10 pts |
| Short Survey | 50 pts |
| Long Survey | 150 pts |
| Streak Bonus | Up to 20 pts |

## Badge System

| Badge | Points Required |
|-------|----------------|
| Starter | 100 |
| Explorer | 500 |
| Champion | 1,000 |
| Elite | 2,500 |
| Master | 5,000 |
| Legend | 10,000 |

## Reward Structure

### Weekly/Monthly Rewards
| Rank | Prize |
|------|-------|
| 1st | $50 |
| 2nd | $30 |
| 3rd | $20 |

## Deployment

### Frontend (Vercel)
1. Push to GitHub
2. Connect to Vercel
3. Set environment variables
4. Deploy

### Backend (Render/Railway/Heroku)
1. Push to GitHub
2. Connect to platform
3. Set environment variables
4. Deploy

### Database (MongoDB Atlas)
1. Create cluster
2. Get connection string
3. Update MONGODB_URI

## Security Features

- Password hashing with bcrypt
- JWT token authentication
- Input validation
- Rate limiting
- CORS protection
- Helmet security headers

## License

MIT License

## Support

For support, email support@nexora.com or join our Discord community.
