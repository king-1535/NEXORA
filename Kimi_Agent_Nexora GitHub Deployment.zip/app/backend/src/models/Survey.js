const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  questionText: {
    type: String,
    required: [true, 'Please provide question text']
  },
  questionType: {
    type: String,
    enum: ['single_choice', 'multiple_choice', 'text', 'rating', 'yes_no'],
    required: true
  },
  options: [{
    type: String
  }],
  required: {
    type: Boolean,
    default: true
  }
});

const surveySchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please provide a survey title'],
    trim: true,
    maxlength: [100, 'Title cannot be more than 100 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot be more than 500 characters']
  },
  type: {
    type: String,
    enum: ['short', 'long'],
    required: true
  },
  questions: [questionSchema],
  points: {
    type: Number,
    required: true,
    min: 0
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'draft'],
    default: 'active'
  },
  completions: {
    type: Number,
    default: 0
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

// Index for faster queries
surveySchema.index({ status: 1, type: 1 });
surveySchema.index({ createdAt: -1 });

module.exports = mongoose.model('Survey', surveySchema);
