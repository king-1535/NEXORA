const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please provide a name'],
    trim: true,
    maxlength: [50, 'Name cannot be more than 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Please provide an email'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\\\
S+@\S+\.\S+$/, 'Please provide a valid email']
  },
  password: {
    type: String,
    required: [true, 'Please provide a password'],
    minlength: [6, 'Password must be at least 6 characters'],
    select: false
  },
  points: {
    type: Number,
    default: 0
  },
  rank: {
    type: Number,
    default: 0
  },
  streak: {
    type: Number,
    default: 0
  },
  lastLoginDate: {
    type: Date,
    default: null
  },
  badges: [{
    type: String,
    enum: ['starter', 'explorer', 'champion', 'elite', 'master', 'legend']
  }],
  completedSurveys: [{
    survey: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Survey'
    },
    completedAt: {
      type: Date,
      default: Date.now
    }
  }],
  isVerified: {
    type: Boolean,
    default: false
  },
  verificationToken: {
    type: String,
    select: false
  },
  verificationTokenExpire: {
    type: Date,
    select: false
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Compare password method
userSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Update rank based on points
userSchema.methods.updateRank = async function() {
  const User = this.model('User');
  const usersWithMorePoints = await User.countDocuments({
    points: { $gt: this.points }
  });
  this.rank = usersWithMorePoints + 1;
  await this.save();
};

// Check and update streak
userSchema.methods.updateStreak = async function() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const lastLogin = this.lastLoginDate ? new Date(this.lastLoginDate) : null;
  if (lastLogin) {
    lastLogin.setHours(0, 0, 0, 0);
  }

  if (!lastLogin) {
    // First login
    this.streak = 1;
  } else {
    const diffTime = today - lastLogin;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      // Consecutive day
      this.streak += 1;
    } else if (diffDays > 1) {
      // Streak broken
      this.streak = 1;
    }
    // If same day, don't change streak
  }

  this.lastLoginDate = new Date();
  await this.save();
};

// Add points and check for badges
userSchema.methods.addPoints = async function(points) {
  this.points += points;
  
  // Check for badge upgrades
  if (this.points >= 10000 && !this.badges.includes('legend')) {
    this.badges.push('legend');
  } else if (this.points >= 5000 && !this.badges.includes('master')) {
    this.badges.push('master');
  } else if (this.points >= 2500 && !this.badges.includes('elite')) {
    this.badges.push('elite');
  } else if (this.points >= 1000 && !this.badges.includes('champion')) {
    this.badges.push('champion');
  } else if (this.points >= 500 && !this.badges.includes('explorer')) {
    this.badges.push('explorer');
  } else if (this.points >= 100 && !this.badges.includes('starter')) {
    this.badges.push('starter');
  }

  await this.save();
  await this.updateRank();
};

module.exports = mongoose.model('User', userSchema);
