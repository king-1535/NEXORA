const mongoose = require('mongoose');

const rewardSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'paid', 'cancelled'],
    default: 'pending'
  },
  period: {
    type: String,
    enum: ['weekly', 'monthly'],
    required: true
  },
  periodStart: {
    type: Date,
    required: true
  },
  periodEnd: {
    type: Date,
    required: true
  },
  rank: {
    type: Number,
    required: true
  },
  paymentMethod: {
    type: String,
    enum: ['paypal', 'bank_transfer', 'gift_card', 'crypto'],
    default: null
  },
  paymentDetails: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  paidAt: {
    type: Date,
    default: null
  },
  paidBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  notes: {
    type: String,
    trim: true
  }
}, {
  timestamps: true
});

// Index for faster queries
rewardSchema.index({ status: 1, period: 1 });
rewardSchema.index({ user: 1, createdAt: -1 });
rewardSchema.index({ periodStart: 1, periodEnd: 1 });

// Static method to calculate rewards for a period
rewardSchema.statics.calculateRewards = async function(periodType, startDate, endDate) {
  const User = mongoose.model('User');
  
  // Get top users by points
  const topUsers = await User.find()
    .sort({ points: -1 })
    .limit(10)
    .select('_id name email points');

  const rewardAmounts = {
    1: 50,  // #1 gets $50
    2: 30,  // #2 gets $30
    3: 20   // #3 gets $20
  };

  const rewards = [];

  for (let i = 0; i < topUsers.length; i++) {
    const rank = i + 1;
    const amount = rewardAmounts[rank] || 0;

    if (amount > 0) {
      // Check if reward already exists
      const existingReward = await this.findOne({
        user: topUsers[i]._id,
        period: periodType,
        periodStart: startDate,
        periodEnd: endDate
      });

      if (!existingReward) {
        const reward = await this.create({
          user: topUsers[i]._id,
          amount: amount,
          period: periodType,
          periodStart: startDate,
          periodEnd: endDate,
          rank: rank,
          status: 'pending'
        });
        rewards.push(reward);
      }
    }
  }

  return rewards;
};

module.exports = mongoose.model('Reward', rewardSchema);
