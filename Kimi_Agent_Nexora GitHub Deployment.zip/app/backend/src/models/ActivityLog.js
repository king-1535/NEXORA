const mongoose = require('mongoose');

const activityLogSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  activityType: {
    type: String,
    enum: ['survey_completion', 'daily_login', 'streak_bonus', 'reward_claimed', 'admin_adjustment'],
    required: true
  },
  survey: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Survey',
    default: null
  },
  pointsEarned: {
    type: Number,
    required: true
  },
  description: {
    type: String,
    trim: true
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  }
}, {
  timestamps: true
});

// Index for faster queries
activityLogSchema.index({ user: 1, createdAt: -1 });
activityLogSchema.index({ activityType: 1 });
activityLogSchema.index({ createdAt: -1 });

// Static method to get user's activity summary
activityLogSchema.statics.getUserSummary = async function(userId, days = 30) {
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  return this.aggregate([
    {
      $match: {
        user: new mongoose.Types.ObjectId(userId),
        createdAt: { $gte: startDate }
      }
    },
    {
      $group: {
        _id: '$activityType',
        totalPoints: { $sum: '$pointsEarned' },
        count: { $sum: 1 }
      }
    }
  ]);
};

module.exports = mongoose.model('ActivityLog', activityLogSchema);
