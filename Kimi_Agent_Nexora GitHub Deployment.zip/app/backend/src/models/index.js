const User = require('./User');
const Survey = require('./Survey');
const ActivityLog = require('./ActivityLog');
const Reward = require('./Reward');

module.exports = {
  User,
  Survey,
  ActivityLog,
  Reward
};
