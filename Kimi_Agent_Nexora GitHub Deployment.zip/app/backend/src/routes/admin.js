const express = require('express');
const { body } = require('express-validator');
const {
  getDashboardStats,
  getRewards,
  updateReward,
  calculateRewards,
  getActivityLogs,
  exportUsers,
  getSettings,
  createAdmin
} = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

// All routes require admin access
router.use(protect, adminOnly);

// Dashboard
router.get('/dashboard', getDashboardStats);

// Rewards
router.get('/rewards', getRewards);
router.put('/rewards/:id', updateReward);
router.post('/rewards/calculate', calculateRewards);

// Activity logs
router.get('/activity-logs', getActivityLogs);

// Export
router.get('/export/users', exportUsers);

// Settings
router.get('/settings', getSettings);

// Create admin
router.post('/create-admin', [
  body('name').trim().isLength({ min: 2 }),
  body('email').isEmail(),
  body('password').isLength({ min: 6 })
], createAdmin);

module.exports = router;
