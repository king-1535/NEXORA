const express = require('express');
const { body } = require('express-validator');
const {
  getSurveys,
  getSurvey,
  createSurvey,
  updateSurvey,
  deleteSurvey,
  submitSurvey,
  getSurveyStats
} = require('../controllers/surveyController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

// Validation middleware for creating/updating surveys
const surveyValidation = [
  body('title')
    .trim()
    .isLength({ min: 3, max: 100 })
    .withMessage('Title must be between 3 and 100 characters'),
  body('type')
    .isIn(['short', 'long'])
    .withMessage('Type must be either short or long'),
  body('questions')
    .isArray({ min: 1 })
    .withMessage('At least one question is required'),
  body('points')
    .isInt({ min: 0 })
    .withMessage('Points must be a positive number')
];

// Routes
router.get('/', protect, getSurveys);
router.get('/stats/overview', protect, adminOnly, getSurveyStats);
router.get('/:id', protect, getSurvey);
router.post('/', protect, adminOnly, surveyValidation, createSurvey);
router.put('/:id', protect, adminOnly, surveyValidation, updateSurvey);
router.delete('/:id', protect, adminOnly, deleteSurvey);
router.post('/:id/submit', protect, submitSurvey);

module.exports = router;
