const express = require('express');
const { body } = require('express-validator');
const {
  getDashboard,
  getActivityLog,
  getLeaderboard,
  updateProfile,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
  adjustPoints
} = require('../controllers/userController');
const { protect, adminOnly } = require('../middleware/auth');

const router = express.Router();

// User routes
router.get('/dashboard', protect, getDashboard);
router.get('/activity', protect, getActivityLog);
router.get('/leaderboard', protect, getLeaderboard);
router.put('/profile', protect, body('name').trim().isLength({ min: 2 }), updateProfile);

// Admin routes
router.get('/', protect, adminOnly, getAllUsers);
router.get('/:id', protect, adminOnly, getUserById);
router.put('/:id', protect, adminOnly, updateUser);
router.delete('/:id', protect, adminOnly, deleteUser);
router.post('/:id/adjust-points', protect, adminOnly, adjustPoints);

module.exports = router;
