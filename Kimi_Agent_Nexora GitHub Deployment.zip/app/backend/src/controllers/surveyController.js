const { validationResult } = require('express-validator');
const { Survey, User, ActivityLog } = require('../models');

// @desc    Get all active surveys
// @route   GET /api/surveys
// @access  Private
exports.getSurveys = async (req, res) => {
  try {
    const { type, status } = req.query;
    const filter = {};

    if (type) filter.type = type;
    if (status) filter.status = status;
    else filter.status = 'active';

    const surveys = await Survey.find(filter)
      .select('-questions.options') // Exclude options for list view
      .sort({ createdAt: -1 });

    // Mark surveys that user has already completed
    const user = await User.findById(req.user.id);
    const completedSurveyIds = user.completedSurveys.map(cs => cs.survey.toString());

    const surveysWithStatus = surveys.map(survey => ({
      ...survey.toObject(),
      isCompleted: completedSurveyIds.includes(survey._id.toString())
    }));

    res.json({
      success: true,
      count: surveys.length,
      data: surveysWithStatus
    });
  } catch (error) {
    console.error('Get surveys error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching surveys'
    });
  }
};

// @desc    Get single survey
// @route   GET /api/surveys/:id
// @access  Private
exports.getSurvey = async (req, res) => {
  try {
    const survey = await Survey.findById(req.params.id);

    if (!survey) {
      return res.status(404).json({
        success: false,
        message: 'Survey not found'
      });
    }

    // Check if user already completed this survey
    const user = await User.findById(req.user.id);
    const isCompleted = user.completedSurveys.some(
      cs => cs.survey.toString() === survey._id.toString()
    );

    if (isCompleted) {
      return res.status(400).json({
        success: false,
        message: 'You have already completed this survey'
      });
    }

    res.json({
      success: true,
      data: survey
    });
  } catch (error) {
    console.error('Get survey error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching survey'
    });
  }
};

// @desc    Create new survey (Admin only)
// @route   POST /api/surveys
// @access  Private/Admin
exports.createSurvey = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { title, description, type, questions, points, status, endDate } = req.body;

    const survey = await Survey.create({
      title,
      description,
      type,
      questions,
      points,
      status: status || 'active',
      createdBy: req.user.id,
      endDate
    });

    res.status(201).json({
      success: true,
      message: 'Survey created successfully',
      data: survey
    });
  } catch (error) {
    console.error('Create survey error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error creating survey'
    });
  }
};

// @desc    Update survey (Admin only)
// @route   PUT /api/surveys/:id
// @access  Private/Admin
exports.updateSurvey = async (req, res) => {
  try {
    const { title, description, type, questions, points, status, endDate } = req.body;

    let survey = await Survey.findById(req.params.id);

    if (!survey) {
      return res.status(404).json({
        success: false,
        message: 'Survey not found'
      });
    }

    survey = await Survey.findByIdAndUpdate(
      req.params.id,
      { title, description, type, questions, points, status, endDate },
      { new: true, runValidators: true }
    );

    res.json({
      success: true,
      message: 'Survey updated successfully',
      data: survey
    });
  } catch (error) {
    console.error('Update survey error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error updating survey'
    });
  }
};

// @desc    Delete survey (Admin only)
// @route   DELETE /api/surveys/:id
// @access  Private/Admin
exports.deleteSurvey = async (req, res) => {
  try {
    const survey = await Survey.findById(req.params.id);

    if (!survey) {
      return res.status(404).json({
        success: false,
        message: 'Survey not found'
      });
    }

    await survey.deleteOne();

    res.json({
      success: true,
      message: 'Survey deleted successfully'
    });
  } catch (error) {
    console.error('Delete survey error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error deleting survey'
    });
  }
};

// @desc    Submit survey response
// @route   POST /api/surveys/:id/submit
// @access  Private
exports.submitSurvey = async (req, res) => {
  try {
    const { answers } = req.body;
    const surveyId = req.params.id;

    const survey = await Survey.findById(surveyId);

    if (!survey) {
      return res.status(404).json({
        success: false,
        message: 'Survey not found'
      });
    }

    if (survey.status !== 'active') {
      return res.status(400).json({
        success: false,
        message: 'This survey is not active'
      });
    }

    // Check if user already completed this survey
    const user = await User.findById(req.user.id);
    const isCompleted = user.completedSurveys.some(
      cs => cs.survey.toString() === surveyId
    );

    if (isCompleted) {
      return res.status(400).json({
        success: false,
        message: 'You have already completed this survey'
      });
    }

    // Validate answers
    if (!answers || !Array.isArray(answers) || answers.length !== survey.questions.length) {
      return res.status(400).json({
        success: false,
        message: 'Please answer all questions'
      });
    }

    // Add survey to user's completed surveys
    user.completedSurveys.push({
      survey: surveyId,
      completedAt: new Date()
    });

    // Add points to user
    await user.addPoints(survey.points);

    // Increment survey completions
    survey.completions += 1;
    await survey.save();

    // Log activity
    await ActivityLog.create({
      user: user._id,
      activityType: 'survey_completion',
      survey: surveyId,
      pointsEarned: survey.points,
      description: `Completed survey: ${survey.title}`,
      metadata: { answers }
    });

    res.json({
      success: true,
      message: 'Survey submitted successfully',
      data: {
        pointsEarned: survey.points,
        totalPoints: user.points,
        newRank: user.rank
      }
    });
  } catch (error) {
    console.error('Submit survey error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error submitting survey'
    });
  }
};

// @desc    Get survey statistics (Admin only)
// @route   GET /api/surveys/stats/overview
// @access  Private/Admin
exports.getSurveyStats = async (req, res) => {
  try {
    const totalSurveys = await Survey.countDocuments();
    const activeSurveys = await Survey.countDocuments({ status: 'active' });
    const totalCompletions = await Survey.aggregate([
      { $group: { _id: null, total: { $sum: '$completions' } } }
    ]);

    const surveysByType = await Survey.aggregate([
      { $group: { _id: '$type', count: { $sum: 1 } } }
    ]);

    res.json({
      success: true,
      data: {
        totalSurveys,
        activeSurveys,
        totalCompletions: totalCompletions[0]?.total || 0,
        surveysByType
      }
    });
  } catch (error) {
    console.error('Get survey stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching survey statistics'
    });
  }
};
