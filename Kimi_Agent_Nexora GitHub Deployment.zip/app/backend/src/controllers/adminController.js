const { User, Survey, ActivityLog, Reward } = require('../models');

// @desc    Get admin dashboard stats
// @route   GET /api/admin/dashboard
// @access  Private/Admin
exports.getDashboardStats = async (req, res) => {
  try {
    // User statistics
    const totalUsers = await User.countDocuments();
    const newUsersToday = await User.countDocuments({
      createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
    });
    const activeUsersToday = await ActivityLog.distinct('user', {
      createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
    });

    // Survey statistics
    const totalSurveys = await Survey.countDocuments();
    const activeSurveys = await Survey.countDocuments({ status: 'active' });
    const totalCompletions = await Survey.aggregate([
      { $group: { _id: null, total: { $sum: '$completions' } } }
    ]);

    // Points statistics
    const totalPointsDistributed = await ActivityLog.aggregate([
      { $group: { _id: null, total: { $sum: '$pointsEarned' } } }
    ]);

    const pointsToday = await ActivityLog.aggregate([
      {
        $match: {
          createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
        }
      },
      { $group: { _id: null, total: { $sum: '$pointsEarned' } } }
    ]);

    // Reward statistics
    const totalRewards = await Reward.countDocuments();
    const pendingRewards = await Reward.countDocuments({ status: 'pending' });
    const totalPaidAmount = await Reward.aggregate([
      { $match: { status: 'paid' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    // Recent activity
    const recentActivity = await ActivityLog.find()
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('user', 'name')
      .populate('survey', 'title');

    // Top users
    const topUsers = await User.find()
      .sort({ points: -1 })
      .limit(5)
      .select('name points rank streak');

    res.json({
      success: true,
      data: {
        users: {
          total: totalUsers,
          newToday: newUsersToday,
          activeToday: activeUsersToday.length
        },
        surveys: {
          total: totalSurveys,
          active: activeSurveys,
          totalCompletions: totalCompletions[0]?.total || 0
        },
        points: {
          totalDistributed: totalPointsDistributed[0]?.total || 0,
          today: pointsToday[0]?.total || 0
        },
        rewards: {
          total: totalRewards,
          pending: pendingRewards,
          totalPaid: totalPaidAmount[0]?.total || 0
        },
        recentActivity,
        topUsers
      }
    });
  } catch (error) {
    console.error('Get admin dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching admin dashboard'
    });
  }
};

// @desc    Get all rewards
// @route   GET /api/admin/rewards
// @access  Private/Admin
exports.getRewards = async (req, res) => {
  try {
    const { status, period, page = 1, limit = 20 } = req.query;

    const filter = {};
    if (status) filter.status = status;
    if (period) filter.period = period;

    const rewards = await Reward.find(filter)
      .populate('user', 'name email')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await Reward.countDocuments(filter);

    res.json({
      success: true,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      data: rewards
    });
  } catch (error) {
    console.error('Get rewards error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching rewards'
    });
  }
};

// @desc    Update reward status
// @route   PUT /api/admin/rewards/:id
// @access  Private/Admin
exports.updateReward = async (req, res) => {
  try {
    const { status, paymentMethod, paymentDetails, notes } = req.body;

    const reward = await Reward.findById(req.params.id);

    if (!reward) {
      return res.status(404).json({
        success: false,
        message: 'Reward not found'
      });
    }

    reward.status = status || reward.status;
    reward.paymentMethod = paymentMethod || reward.paymentMethod;
    reward.paymentDetails = paymentDetails || reward.paymentDetails;
    reward.notes = notes || reward.notes;

    if (status === 'paid') {
      reward.paidAt = new Date();
      reward.paidBy = req.user.id;
    }

    await reward.save();

    res.json({
      success: true,
      message: 'Reward updated successfully',
      data: reward
    });
  } catch (error) {
    console.error('Update reward error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error updating reward'
    });
  }
};

// @desc    Calculate and create rewards for a period
// @route   POST /api/admin/rewards/calculate
// @access  Private/Admin
exports.calculateRewards = async (req, res) => {
  try {
    const { period, startDate, endDate } = req.body;

    if (!period || !startDate || !endDate) {
      return res.status(400).json({
        success: false,
        message: 'Please provide period, startDate, and endDate'
      });
    }

    const rewards = await Reward.calculateRewards(
      period,
      new Date(startDate),
      new Date(endDate)
    );

    res.json({
      success: true,
      message: `Calculated ${rewards.length} rewards for ${period} period`,
      data: rewards
    });
  } catch (error) {
    console.error('Calculate rewards error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error calculating rewards'
    });
  }
};

// @desc    Get activity logs
// @route   GET /api/admin/activity-logs
// @access  Private/Admin
exports.getActivityLogs = async (req, res) => {
  try {
    const { userId, activityType, page = 1, limit = 50 } = req.query;

    const filter = {};
    if (userId) filter.user = userId;
    if (activityType) filter.activityType = activityType;

    const logs = await ActivityLog.find(filter)
      .populate('user', 'name email')
      .populate('survey', 'title')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await ActivityLog.countDocuments(filter);

    res.json({
      success: true,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      data: logs
    });
  } catch (error) {
    console.error('Get activity logs error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching activity logs'
    });
  }
};

// @desc    Export user data
// @route   GET /api/admin/export/users
// @access  Private/Admin
exports.exportUsers = async (req, res) => {
  try {
    const users = await User.find()
      .select('-password -verificationToken -verificationTokenExpire -resetPasswordToken -resetPasswordExpire')
      .sort({ createdAt: -1 });

    // Format for CSV export
    const formattedUsers = users.map(user => ({
      id: user._id,
      name: user.name,
      email: user.email,
      points: user.points,
      rank: user.rank,
      streak: user.streak,
      badges: user.badges.join(', '),
      completedSurveys: user.completedSurveys.length,
      isVerified: user.isVerified,
      role: user.role,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt
    }));

    res.json({
      success: true,
      count: formattedUsers.length,
      data: formattedUsers
    });
  } catch (error) {
    console.error('Export users error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error exporting users'
    });
  }
};

// @desc    Get system settings
// @route   GET /api/admin/settings
// @access  Private/Admin
exports.getSettings = async (req, res) => {
  try {
    // Return system settings (can be stored in database)
    const settings = {
      pointValues: {
        dailyLogin: 10,
        shortSurvey: 50,
        longSurvey: 150
      },
      streakBonus: {
        enabled: true,
        maxBonus: 20,
        multiplier: 2
      },
      rewards: {
        weekly: {
          first: 50,
          second: 30,
          third: 20
        },
        monthly: {
          first: 50,
          second: 30,
          third: 20
        }
      },
      badges: {
        starter: 100,
        explorer: 500,
        champion: 1000,
        elite: 2500,
        master: 5000,
        legend: 10000
      }
    };

    res.json({
      success: true,
      data: settings
    });
  } catch (error) {
    console.error('Get settings error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching settings'
    });
  }
};

// @desc    Create admin user
// @route   POST /api/admin/create-admin
// @access  Private/Admin
exports.createAdmin = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email'
      });
    }

    // Create admin user
    const admin = await User.create({
      name,
      email,
      password,
      role: 'admin',
      isVerified: true
    });

    res.status(201).json({
      success: true,
      message: 'Admin user created successfully',
      data: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: admin.role
      }
    });
  } catch (error) {
    console.error('Create admin error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error creating admin'
    });
  }
};
