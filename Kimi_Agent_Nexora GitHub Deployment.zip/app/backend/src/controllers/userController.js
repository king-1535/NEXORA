const { User, ActivityLog, Reward } = require('../models');

// @desc    Get user dashboard data
// @route   GET /api/users/dashboard
// @access  Private
exports.getDashboard = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    // Get recent activity
    const recentActivity = await ActivityLog.find({ user: user._id })
      .sort({ createdAt: -1 })
      .limit(10)
      .populate('survey', 'title');

    // Get activity summary
    const activitySummary = await ActivityLog.getUserSummary(user._id, 30);

    // Get user's rewards
    const rewards = await Reward.find({ user: user._id })
      .sort({ createdAt: -1 })
      .limit(5);

    // Get next badge progress
    const badgeThresholds = {
      starter: 100,
      explorer: 500,
      champion: 1000,
      elite: 2500,
      master: 5000,
      legend: 10000
    };

    let nextBadge = null;
    let progressToNext = 0;

    for (const [badge, threshold] of Object.entries(badgeThresholds)) {
      if (!user.badges.includes(badge)) {
        nextBadge = { name: badge, threshold };
        progressToNext = Math.min((user.points / threshold) * 100, 100);
        break;
      }
    }

    res.json({
      success: true,
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          points: user.points,
          rank: user.rank,
          streak: user.streak,
          badges: user.badges,
          completedSurveysCount: user.completedSurveys.length
        },
        recentActivity,
        activitySummary,
        rewards,
        nextBadge,
        progressToNext
      }
    });
  } catch (error) {
    console.error('Get dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching dashboard'
    });
  }
};

// @desc    Get user activity log
// @route   GET /api/users/activity
// @access  Private
exports.getActivityLog = async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;

    const activities = await ActivityLog.find({ user: req.user.id })
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('survey', 'title');

    const count = await ActivityLog.countDocuments({ user: req.user.id });

    res.json({
      success: true,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      data: activities
    });
  } catch (error) {
    console.error('Get activity log error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching activity log'
    });
  }
};

// @desc    Get leaderboard
// @route   GET /api/users/leaderboard
// @access  Private
exports.getLeaderboard = async (req, res) => {
  try {
    const { period = 'all', limit = 10 } = req.query;

    let users;

    if (period === 'weekly') {
      const startOfWeek = new Date();
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
      startOfWeek.setHours(0, 0, 0, 0);

      // Get weekly activity
      const weeklyActivity = await ActivityLog.aggregate([
        {
          $match: {
            createdAt: { $gte: startOfWeek }
          }
        },
        {
          $group: {
            _id: '$user',
            weeklyPoints: { $sum: '$pointsEarned' }
          }
        },
        {
          $sort: { weeklyPoints: -1 }
        },
        {
          $limit: parseInt(limit)
        }
      ]);

      // Get user details
      const userIds = weeklyActivity.map(a => a._id);
      const userDetails = await User.find({ _id: { $in: userIds } });

      users = weeklyActivity.map((activity, index) => {
        const userDetail = userDetails.find(u => u._id.toString() === activity._id.toString());
        return {
          rank: index + 1,
          user: {
            id: userDetail?._id,
            name: userDetail?.name,
            badges: userDetail?.badges
          },
          points: activity.weeklyPoints
        };
      });
    } else if (period === 'monthly') {
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const monthlyActivity = await ActivityLog.aggregate([
        {
          $match: {
            createdAt: { $gte: startOfMonth }
          }
        },
        {
          $group: {
            _id: '$user',
            monthlyPoints: { $sum: '$pointsEarned' }
          }
        },
        {
          $sort: { monthlyPoints: -1 }
        },
        {
          $limit: parseInt(limit)
        }
      ]);

      const userIds = monthlyActivity.map(a => a._id);
      const userDetails = await User.find({ _id: { $in: userIds } });

      users = monthlyActivity.map((activity, index) => {
        const userDetail = userDetails.find(u => u._id.toString() === activity._id.toString());
        return {
          rank: index + 1,
          user: {
            id: userDetail?._id,
            name: userDetail?.name,
            badges: userDetail?.badges
          },
          points: activity.monthlyPoints
        };
      });
    } else {
      // All time leaderboard
      const topUsers = await User.find()
        .sort({ points: -1 })
        .limit(parseInt(limit))
        .select('name points badges rank');

      users = topUsers.map((user, index) => ({
        rank: index + 1,
        user: {
          id: user._id,
          name: user.name,
          badges: user.badges
        },
        points: user.points
      }));
    }

    // Get current user's rank
    const currentUser = await User.findById(req.user.id);
    const currentUserRank = await User.countDocuments({
      points: { $gt: currentUser.points }
    }) + 1;

    res.json({
      success: true,
      period,
      data: {
        leaderboard: users,
        currentUser: {
          rank: currentUserRank,
          points: currentUser.points,
          name: currentUser.name
        }
      }
    });
  } catch (error) {
    console.error('Get leaderboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching leaderboard'
    });
  }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
exports.updateProfile = async (req, res) => {
  try {
    const { name } = req.body;

    const user = await User.findByIdAndUpdate(
      req.user.id,
      { name },
      { new: true, runValidators: true }
    );

    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error updating profile'
    });
  }
};

// @desc    Get all users (Admin only)
// @route   GET /api/users
// @access  Private/Admin
exports.getAllUsers = async (req, res) => {
  try {
    const { page = 1, limit = 20, search, sortBy = 'points', order = 'desc' } = req.query;

    const filter = {};
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }

    const sortOrder = order === 'desc' ? -1 : 1;
    const sort = {};
    sort[sortBy] = sortOrder;

    const users = await User.find(filter)
      .select('-password')
      .sort(sort)
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await User.countDocuments(filter);

    res.json({
      success: true,
      count,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      data: users
    });
  } catch (error) {
    console.error('Get all users error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching users'
    });
  }
};

// @desc    Get user by ID (Admin only)
// @route   GET /api/users/:id
// @access  Private/Admin
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Get user's activity
    const recentActivity = await ActivityLog.find({ user: user._id })
      .sort({ createdAt: -1 })
      .limit(10);

    // Get user's rewards
    const rewards = await Reward.find({ user: user._id })
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      data: {
        user,
        recentActivity,
        rewards
      }
    });
  } catch (error) {
    console.error('Get user by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error fetching user'
    });
  }
};

// @desc    Update user (Admin only)
// @route   PUT /api/users/:id
// @access  Private/Admin
exports.updateUser = async (req, res) => {
  try {
    const { name, email, points, role, isVerified } = req.body;

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email, points, role, isVerified },
      { new: true, runValidators: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update rank after points change
    if (points !== undefined) {
      await user.updateRank();
    }

    res.json({
      success: true,
      message: 'User updated successfully',
      data: user
    });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error updating user'
    });
  }
};

// @desc    Delete user (Admin only)
// @route   DELETE /api/users/:id
// @access  Private/Admin
exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    await user.deleteOne();

    // Clean up related data
    await ActivityLog.deleteMany({ user: req.params.id });
    await Reward.deleteMany({ user: req.params.id });

    res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error deleting user'
    });
  }
};

// @desc    Adjust user points (Admin only)
// @route   POST /api/users/:id/adjust-points
// @access  Private/Admin
exports.adjustPoints = async (req, res) => {
  try {
    const { points, reason } = req.body;

    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const oldPoints = user.points;
    await user.addPoints(points);

    // Log activity
    await ActivityLog.create({
      user: user._id,
      activityType: 'admin_adjustment',
      pointsEarned: points,
      description: reason || `Admin adjusted points by ${points > 0 ? '+' : ''}${points}`,
      metadata: { oldPoints, newPoints: user.points, adjustedBy: req.user.id }
    });

    res.json({
      success: true,
      message: 'Points adjusted successfully',
      data: {
        oldPoints,
        newPoints: user.points,
        adjustment: points
      }
    });
  } catch (error) {
    console.error('Adjust points error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error adjusting points'
    });
  }
};
